<div id="footer">
	<h3> METRICA FOR TEST </h3>
	<p>Собираем данные с сайтов для целей вашей статистики!</p>
</div>