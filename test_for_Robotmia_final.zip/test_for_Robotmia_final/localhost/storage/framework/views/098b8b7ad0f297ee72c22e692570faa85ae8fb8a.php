
<?php $__env->startSection('title', 'Список городов'); ?>
<?php $__env->startSection('menu', '__here will be menu____'); ?>
<?php $__env->startSection('main'); ?>
	<table>
		<caption>Список улиц города <?php echo e($city->city_name); ?></caption>
		<tr>
			<head>
				<th>Название</th>
				<th>Длина</th>
			</head>
			<?php if(count($city->street)>0): ?>
				<?php $__currentLoopData = $city->street; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $street): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<td><?php echo e($street->main_street_name); ?></td>
				<td><?php echo e($street->main_street_length); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tr>
	</table>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/cityDescription.blade.php ENDPATH**/ ?>