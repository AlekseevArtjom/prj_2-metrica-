<div>
    your try to bye the detail: <?php echo e($detailName); ?>

</div><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\storage\framework\views/fde2a6a5dc78db08d91f344b5503ff0ec58aa982.blade.php ENDPATH**/ ?>