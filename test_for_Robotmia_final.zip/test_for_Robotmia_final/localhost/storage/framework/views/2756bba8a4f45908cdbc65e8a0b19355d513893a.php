

<?php $__env->startSection('main'); ?>

<h1>Collections</h1>

<?php if (\Illuminate\Support\Facades\Blade::check('pidoras', 'tom')): ?>
<?php echo '<h1> ИДИ НА ХУЙ гнойный '.'Пидорас'.'! </h1>'; ?>;
<?php else: ?> <h1>Мужик</h1>  <!-- в книге ошибка else пишется без имени директивы если ето не вложенный подзапрос  -->
<?php endif; ?> 


<?php if(empty($init_massiv)): ?>  
	<p>No content in collection</p>
	<?php else: ?> <p>Initial massive: <?php echo e($init_massiv); ?></p>
<?php endif; ?>

<?php if(empty($test1)): ?>  
	<p>No content in collection</p>
	<?php else: ?> <p>Test 1 massive: <?php echo e($test1); ?></p>
<?php endif; ?>


<?php if(empty($extracted)): ?>  
	<p>No content in collection</p>
	<?php else: ?> <p>Extracted: <?php echo e($extracted); ?></p>
<?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/collections.blade.php ENDPATH**/ ?>