



<?php $__env->startSection('title', 'Список городов'); ?>
<?php $__env->startSection('menu', '__here will be menu____'); ?>
<?php $__env->startSection('main'); ?>
	<table>
		<caption>Список всех городов</caption>
		<tr>
			<head>
				<th>Название</th>
				<th>Население</th>
				<th>Бюджет</th>
				<th>Столица</th>
				<th>Улицы</th>
				<th>Экскурсии</th>
			</head>
			<?php if($city_amount>0): ?>
				<?php $__currentLoopData = $listOfCity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curent_city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<td><?php echo e($curent_city->city_name); ?></td>
				<td><?php echo e($curent_city->cityzen_amount); ?></td>
				<td><?php echo e($curent_city->city_cash); ?></td>
				<td><?php echo e($curent_city->state_capital); ?></td>
				<td><a href="<?php echo e(route('streets', ['city'=>$curent_city])); ?>">Посмотреть улицы</a></td>
				<td><a href="<?php echo e(route('tours', ['currentCity'=>$curent_city->id])); ?>">Посмотреть экскурсии</a></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</tr>
	</table>
<?php if(auth()->guard()->check()): ?><a href="<?php echo e(route('cityMenu')); ?>">Управление городами</a><?php endif; ?>
<!-- а если подключить шаблон внутри одного из блоков выводимых в базовый шаблон то все работает нормально -->
<?php if ($__env->exists('shared.listOfCountryes', ['countryStatus'=>'suverenitet'])) echo $__env->make('shared.listOfCountryes', ['countryStatus'=>'suverenitet'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>


<?php $__env->startPush('stylesheetsMy'); ?> 
	<style> table th {color: blue;} </style>
<?php $__env->stopPush(); ?>


<?php $__env->startPrepend('stylesheetsMy'); ?>
	<style> table th {color: green;} </style>
<?php $__env->stopPrepend(); ?>

<?php $__env->startPrepend('stylesheetsMy'); ?>
	<style> table td {color:violet;} </style>
<?php $__env->stopPrepend(); ?>

<!-- поскольку шаблон ListOfCities расширяет шаблон initial
 то он вставляет секции в начальный базовый шаблон
 если какая то секция или блок не в текущем шаблоне ListOfCity не входит в базовый шаблон то 
 она вставляется в результирующую страницу в начало перед базовым шаблоном  втом порядке как она появилась 
здесь и к ней не применяются стили базового шаблона или теги мета

ВАЖНО при наличии в шаблоне наследнике таких неучтеных блоков и секций тег head полученной страницы ПУСТОЙ!!
а все данные базового шаблона из head помещены в body (включая теги мета и стили) сразу после всех 
неучтеных блоков шаблона-наследника
-->
<?php if ($__env->exists('shared.listOfCountryes', ['countryStatus'=>'suverenitet'])) echo $__env->make('shared.listOfCountryes', ['countryStatus'=>'suverenitet'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div> HELLO!!! </div>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/CityList.blade.php ENDPATH**/ ?>