<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>my_metrica:: <?php echo $__env->yieldContent('title', '________'); ?></title>
	
	<?php echo $__env->yieldPushContent('stylesheets_for_metrica'); ?>
	<?php echo $__env->yieldPushContent('scripts_for_metrica'); ?>

</head>
<body>
<?php if (! empty(trim($__env->yieldContent('headline')))): ?>
	<?php echo $__env->yieldContent('headline'); ?>
<?php else: ?>   <?php if ($__env->exists('shared.defaultHeadline')) echo $__env->make('shared.defaultHeadline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

 
	<?php echo $__env->yieldContent('main'); ?>
	

<?php if (! empty(trim($__env->yieldContent('footer')))): ?>
	<?php echo $__env->yieldContent('footer'); ?>
<?php else: ?>   <?php if ($__env->exists('shared.defaultFooter')) echo $__env->make('shared.defaultFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

</body>
</html>
<?php /**PATH H:\OpenServerBasic\OSPanel\domains\localhost\resources\views/layouts/base.blade.php ENDPATH**/ ?>