


<?php $__env->startPush('stylesheets_for_metrica'); ?>
	<link type="text/css" rel="stylesheet" href="styles/metricaMainStyle.css"/>
	<link type="text/css" rel="stylesheet" href="styles/metricaMainPageStyle.css"/>

	<link type="text/css" rel="stylesheet" href="scripts/jquery-ui-1.12.1.custom/jquery-ui.min.css" />
	<link type="text/css" rel="stylesheet" href="scripts/jquery-ui-1.12.1.custom/jquery-ui.structure.min.css" />
	<link type="text/css" rel="stylesheet" href="scripts/jquery-ui-1.12.1.custom/jquery-ui.theme.min.css" />
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts_for_metrica'); ?>
	<script src="scripts/metricaPageLoader.js" type="text/javascript"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('title'); ?>
	MetricaPage
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

	<h1>Обработка метрики сайтов</h1> 
	<?php if(isset($error_msg) && $error_msg!=null && $error_msg!=''): ?><p><?php echo e($error_msg); ?></p>
	<?php endif; ?>

	
	<div id="addSitePage"><a href="<?php echo e(route('addNewSiteForm')); ?>">Добавить новый сайт</a></div>

	<div id="siteList">
		<h3>Список обслуживаемых сайтов</h3>
		<select id="urlList">
				<option value="0">Выберите сайт для показа метрики</option>
			<?php for($ii=0; $ii<count($siteUrl); $ii++): ?>
				<option value="<?php echo e($siteUrl[$ii]->id); ?>"><?php echo e($siteUrl[$ii]->site_domain); ?></option>
			<?php endfor; ?>
		</select>
	</div>

	<div id="refsOfCurrentSiteList">
		<h3>Страницы сайта</h3>
		<p>Кликните на ссылку, чтобы показать данные</p>
		<ul></ul>
	</div>


	<div id="graphicsClicksTimes"></div>
	<div id="ClickMap"> <iframe id="frameSite" name="SitePageArea" src=""></iframe> </div>


<div id="dialogSetDate" style="display: none">
		<select></select>
		<input type="button" value="Выбрать"/>
		<input type="button" value="Отмена"/>
	</div>






	
	<?php echo csrf_field(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\OpenServerBasic\OSPanel\domains\localhost\resources\views/metricaPage.blade.php ENDPATH**/ ?>