<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>mtTestCite:: <?php echo $__env->yieldContent('title', '________'); ?></title>
	
	<!-- <link type="text/css" rel="stylesheet" href=""/> -->
	<?php echo $__env->yieldPushContent('stylesheetsMy'); ?>

</head>
<body>

	
	<?php if(!isset($requestNewUser)) $requestNewUser='off';
	?>
	<?php echo $__env->make('shared.menuMyBlade', ['requestNewUser'=>$requestNewUser], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
</br>
</br>
	<?php $__env->startSection('main'); ?><h2>Welcome to main!</h2> <?php echo $__env->yieldSection(); ?>

	</br><a href="<?php echo e(route('startPage')); ?>">На главную</a>


<?php if (! empty(trim($__env->yieldContent('footer')))): ?>
	<?php echo $__env->yieldContent('footer'); ?>
<?php else: ?> <h3>no footer here</h3>
<?php endif; ?>

<!-- включение шаблона по его псевдониму из ServiceProvider Boot -->
<?php echo $__env->make('shared.footer', ['message'=>'This is new footer!'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php if ($__env->exists('shared.listOfCountryes', ['countryStatus'=>'ARMY'])) echo $__env->make('shared.listOfCountryes', ['countryStatus'=>'ARMY'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/layouts/initial.blade.php ENDPATH**/ ?>