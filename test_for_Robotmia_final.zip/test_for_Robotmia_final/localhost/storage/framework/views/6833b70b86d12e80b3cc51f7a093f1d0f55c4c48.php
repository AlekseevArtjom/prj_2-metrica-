

<?php $__env->startSection('title', 'Разработчик'); ?>
<!-- @section('menu', '') -->
<?php $__env->startSection('main'); ?> 
	<?php echo \Illuminate\View\Factory::parentPlaceholder('main'); ?>
	Creator is I am!!! </br></br>
	<?php echo e("<h2>test</h2>"); ?> </br> <?php echo '<h2>test</h2>'; ?>

	</br></br> Ilive in <?php echo e($test[3]->city_name); ?>

</br></br>

<?php if (! (4>5)): ?> <p>4<5</p>
<?php else: ?> <p>Error</p>
<?php endif; ?>

<?php $t=1; $r=6; ?>

<?php if(isset($t,$r)): ?> <p>Variables defined!</p>
<?php else: ?> <p>Define the variables!</p>
<?php endif; ?>

<?php if(empty($p)): ?> <h3>Empty</h3>
<?php else: ?> <h3>Variable 'p' is defined!</h3>
<?php endif; ?>

<?php if(app()->environment('local')): ?> <h1>Site work in developement regime.</h1>
<?php else: ?> <h1>Site work in product regime.</h1>
<?php endif; ?>

<?php if(app()->environment('production')): ?> <a href="">Переход на сервер сайта</a>
<?php else: ?> <a href="">Переход на сервер сайта (НЕДОСТУПЕН сайт еще в разработке)</a>
<?php endif; ?>

<?php $t=1; $mass=['apple', 'orange', 'pineaple']; ?>
	<?php switch($t):
		case (1): ?> <ol><?php $__empty_1 = true; $__currentLoopData = $mass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><li><?php echo e($list); ?> : : <?php echo e($loop->count); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p>Fuck the fruit!</p><?php endif; ?></ol> <?php break; ?>
		<?php case (2): ?> <ul><?php $__empty_1 = true; $__currentLoopData = $mass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><li><?php echo e($list); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <p>Fuck the fruit!</p><?php endif; ?></ul> <?php break; ?>
		<?php default: ?> <p>Список недоступен!</p>
	<?php endswitch; ?>

<!-- в цикле for объекта $loop НЕТ!!! -->

<?php for($i=7;$i>0;$i--): ?> 
	<?php if($i==5) continue; ?>
		<?php echo $i."  </br>"; ?>  
	<?php if($i==2) break; ?> 
<?php endfor; ?> 
<?php printf("</br>_____5 \n 4_"); /* все работает php печатает в с новой строки выводит в html а он т.к. нет тега перевода строки текст выведенный php выводит в одну стр */ ?>

{{ директива не обрабатывается шаблонизатором а выводится как есть }}
@if($no==0)


	<h2>И это не обрабатывается шаблонизатором {{$tmp}}</h2>


<?php $fil='Kant Kukant'; ?>
 <?php if (isset($component)) { $__componentOriginal1b714ada3ede753795bc18365c911b854cd836b1 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BackCallForm::class, ['listType' => 'ol','filosof' => $fil,'count' => '10']); ?>
<?php $component->withName('back-call-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal1b714ada3ede753795bc18365c911b854cd836b1)): ?>
<?php $component = $__componentOriginal1b714ada3ede753795bc18365c911b854cd836b1; ?>
<?php unset($__componentOriginal1b714ada3ede753795bc18365c911b854cd836b1); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


<!-- почему при вставке тега со слотом ошибка(когда пытаюсь вывести слот в компоненте получающим параметры)????? 
x-back-call-form listType="ul" :filosof="$fil" count="2">
<p>ertertrtetrt</p>
/x-back-call-form listType="ul" :filosof="$fil" count="2">
-->

 <?php if (isset($component)) { $__componentOriginalfb8063cdaa575f80e2e2958df0734c7563097ed7 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TestSlot::class, []); ?>
<?php $component->withName('test-slot'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	<p>RRRRRRRRRRRRRRRR</p>  <!-- теперь работает НО ТОЛЬКО когда не передаю данные в компонент -->
 <?php if (isset($__componentOriginalfb8063cdaa575f80e2e2958df0734c7563097ed7)): ?>
<?php $component = $__componentOriginalfb8063cdaa575f80e2e2958df0734c7563097ed7; ?>
<?php unset($__componentOriginalfb8063cdaa575f80e2e2958df0734c7563097ed7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

 <?php if (isset($component)) { $__componentOriginale1d1d666e1ecb294f0d776e6ea761efbaa87f7f2 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\ComponentWithoutBlade::class, ['detail' => '3']); ?>
<?php $component->withName('component-without-blade'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginale1d1d666e1ecb294f0d776e6ea761efbaa87f7f2)): ?>
<?php $component = $__componentOriginale1d1d666e1ecb294f0d776e6ea761efbaa87f7f2; ?>
<?php unset($__componentOriginale1d1d666e1ecb294f0d776e6ea761efbaa87f7f2); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 


</br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/creatorPage.blade.php ENDPATH**/ ?>