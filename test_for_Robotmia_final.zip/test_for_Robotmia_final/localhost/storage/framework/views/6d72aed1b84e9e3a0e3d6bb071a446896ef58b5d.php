<div style="font-weight: bold; color: red; background-color: rgba(0,100,10, 0.3);">
     It is not the man who has too little, but the man who craves more, that is poor. - Seneca </br>
	Craves is not bad, bad is not to crave. <?php echo e($filosof); ?>

	<<?php echo e($listType); ?>> 
		<?php $__currentLoopData = $countingNow($count); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
			<li>current countdown=<?php echo e($current); ?></li> 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
	</<?php echo e($listType); ?>>
	<?php if(isset($slot)): ?> <?php echo e($slot); ?> <?php endif; ?>
</div><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/components/back-call-form.blade.php ENDPATH**/ ?>