<div id=footer>
	<div style="background-color: red; max-width: 50%; min-height: 10px;"></div>
	<?php echo e($message); ?> ____ 
		<?php if(isset($city_amount)): ?> <?php echo e($city_amount); ?> 
			<?php else: ?> ... 
		<?php endif; ?>
	<div style="background-color: red; max-width: 50%; min-height: 10px;"></div>
</div><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/shared/footer.blade.php ENDPATH**/ ?>