
<?php $__env->startSection('title', 'Список достопримечательностей'); ?>
<?php $__env->startSection('menu', '__here will be menu____'); ?>
<?php $__env->startSection('main'); ?>

@push('stylesheetsMy') 
	<!-- 
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
	-->
@endpush

<?php if($msg!=null && $msg!=''): ?> <p><?php echo e($msg); ?></p> <?php endif; ?>
	<h2>Достопримечательности городов</h2>
	<table>
		<head>
			<tr>
				<th>Название</th>
				<th>Местоположения</th>
				<th>Доступность</th>
				<?php if(auth()->guard()->check()): ?><th>Действия</th><?php endif; ?>
			</tr>
		</head>
		 <?php for($i=0; $i<count($sitesPaginated); $i++): ?> 
		<tr> 
			<td><?php echo e($sitesPaginated->items()[$i]->sight_name); ?></td>
			<td><?php echo e($sitesPaginated->items()[$i]->city); ?></td>
			<td><?php echo e($sitesPaginated->items()[$i]->avaliability); ?></td>
		<?php if(auth()->guard()->check()): ?><td>  		<?php $ii=$i+($sitesPaginated->currentPage()-1)*$sitesPaginated->perPage(); echo $ii;   ?>
				<input type="button" name='edit' value="Изменить" onclick="(function (){window.location.href='<?php echo e(route('CitySiteRes.edit', ['CitySiteRe'=>$CitySiteRe[$ii]])); ?>';})();" />
				<form style="display: inline;" method="POST" action="<?php echo e(route('CitySiteRes.destroy', ['CitySiteRe'=>$CitySiteRe[$ii]])); ?>">
					<?php echo csrf_field(); ?>
					<?php echo method_field('delete'); ?>
					<input type="submit" value="Удалить" />  
				</form>
			</td>
		<?php endif; ?>
		</tr>
		 <?php endfor; ?> 
		<?php /*
		@foreach($sitesPaginated as $PP)
			<tr> 
			<td>{{$PP->sight_name}}</td>
			<td>{{$PP->city}}</td>
			<td>{{$PP->avaliability}}</td>
			<td>
				<input type="button" name='edit' value="Изменить" onclick="(function (){window.location.href='{{route('CitySiteRes.edit', ['CitySiteRe'=>$CitySiteRe[0]])}}';})();" />
				<form style="display: inline;" method="POST" action="{{route('CitySiteRes.destroy', ['CitySiteRe'=>$CitySiteRe[0]])}}">
					@csrf
					@method('delete')
					<input type="submit" value="Удалить" />  
				</form>
			</td>
		</tr>
		@endforeach */ ?>
	</table>

</br>
<?php if(auth()->guard()->check()): ?>
	<div>	
<input type="button" name='create' value="Добавить достопримечательность" onclick="(function(){window.location.href='<?php echo e(route('CitySiteRes.create')); ?>';})();" />
	</div>
<?php endif; ?>

</br><?php echo e($sitesPaginated->links('CitySiteResView.myFirstPaginatorFORCitySiteList', ["linkColor"=>'red', "linkFontSize"=>'2vw'])); ?>   


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/CitySiteResView/paginatedIndexCitySite.blade.php ENDPATH**/ ?>