
    <div style=" border-radius: 50%;
		 background-color: brown;
		 width: 10%;
		 aspect-ratio: 1; 
		border: black 2px solid; 
		text-align: center; display: table;">
	<div style="border: solid red 1px; display: table-cell; vertical-align: middle;">Hi!</br> Bitch! </div>
	<?php echo e($slot); ?>

    </div>
<?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/components/test-slot.blade.php ENDPATH**/ ?>