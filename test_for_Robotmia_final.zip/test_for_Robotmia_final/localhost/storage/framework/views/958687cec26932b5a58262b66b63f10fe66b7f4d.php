<div>
	<h3> ___Paginator___</h3>
<?php if($paginator->hasPages()): ?> <!-- если есть более чем 1 страница для отображения -->
<style>
	li { list-style-type: none; display: inline; }
	ul{  }
</style>
<ul>
	<?php if($paginator->onfirstPage()): ?>
		<li class="disabled">&laquo</li>
	<?php else: ?>   <li class="arrow"><a href="<?php echo e($paginator->previousPageUrl()); ?>">&laquo</a></li>
	<?php endif; ?>  	


	<?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if(is_string($element)): ?> <li>...</li>
		<?php endif; ?>

		<?php if(is_array($element)): ?>
			<?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page=>$currentUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($page==$paginator->currentPage()): ?>
				      <li>|<?php echo e($page); ?>|</li>
				<?php else: ?> <li><a href="<?php echo e($currentUrl); ?>">|<?php echo e($page); ?>|</a></li>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	
		
	


	<?php if($paginator->hasMorePages()): ?>
		<li class="arrow"><a href="<?php echo e($paginator->nextPageUrl()); ?>">&raquo</a></li>
	<?php else: ?>  	<li class="disabled">&raquo</li>
	<?php endif; ?>



</ul>
<?php else: ?> <p>all data is placed on this page so paginator no need here</p>

<?php endif; ?>



</div><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/CitySiteResView/myFirstPaginatorFORCitySiteList.blade.php ENDPATH**/ ?>