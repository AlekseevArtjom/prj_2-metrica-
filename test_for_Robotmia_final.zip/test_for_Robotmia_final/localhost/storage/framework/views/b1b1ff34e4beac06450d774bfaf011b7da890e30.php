

<?php $__env->startSection('main'); ?>

<h2>admin panel</h2>
Проверка работы функций обработки строк  \ массивов \ хелперов

<h3>Обработка строк</h3>

<?php
	use Illuminate\Support\Str; //для обработки строк
	use Illuminate\Support\Stringable; // для обработки строк
	use Illuminate\Support\Arr; //для обработки массивов


	$initial_string='this is a Testing_string for purposes Of checking the StringFunction in Laravel is и проверки работы хелперов';
	$init_str = new Stringable($initial_string);
?>

	<p> Исходная строка: <?php echo e($initial_string); ?> </p>
<ol>
<li>Длина строки: <?php echo Str::length($initial_string); ?> или так <?php echo $init_str->length(); ?>  </li>
<li>Добавка к строке другой строки в конце: <?php $add='добавка в конце'; echo $init_str->append($add); ?></li>
<li>Добавка к строке другой строки в начале: <?php $add='добавка в начале'; echo $init_str->prepend($add); ?></li>
<li>Добавка префикса если его нето в начале:(а он есть) <?php echo Str::start($initial_string, 'this'); ?></li>
<li>Добавка префикса если его нето в начале: <?php echo $init_str->start('RRR'); ?></li>
<li>Добавка постфикса <?php echo $init_str->finish('работы хОлперов'); ?> или так <?php echo '</br>'.Str::finish($initial_string, 'TTT'); ?></li>
<li>Сравение строк на полное совпадение: <?php if($init_str->exactly('this Is a Testing_string for purposes of checking the StringFunction in Laravel и проверки работы хелперов'))
						echo 'true'; else echo 'false'; ?></li>
<li>Совпадение с шаблоном Str: <?php if(Str::is('t *t', 't  rt')) echo 'true'; else echo 'false'; ?> --в книге ОШИБКА в этой функции сначала ШАБЛОН затем строка</li>
<li>Совпадение с шаблоном stringable: <?php if(Str::of('trt')->is('*rt')) echo 'true'; else echo 'false'; ?> Функция is (и в Str  и в stringable в шаблоне допускает ТОЛЬКО символ * остальные ЭКРАНИРУЕТ!!!)</li>
<li>Пустая строка?: <?php if($init_str->isEmpty()) echo 'true'; else echo 'false'; ?></li>
<li>Не пустая строка?: <?php if($init_str->isNotEmpty()) echo 'true'; else echo 'false'; ?></li>
<li>Содержит олько ascii? <?php if($init_str->ascii()) echo 'true'; else echo 'false'; ?></li>
<li>Содержит олько ascii('#$%$)@)%%*#*U$(%_№_®_§_¿_∑')? <?php if(/*Str::isAscii('#$%$)@)%%*#*U$(%_№_®_§_¿_∑')*/Str::of('#$%$)@)%%*#*U$(%_№_®_§_¿_∑')->isAscii()) echo 'true!!!'; else echo 'false'; ?></li> 
<li>Уникальный идентификатор? <?php echo '___'; Str::isUuid($initial_string)?$t='yes':$t='no'; echo $t.'___'; ?></li>
<li><?php echo '</br>'.Str::upper('преоБразоВание СтроК'); ?> или так <?php echo Str::of('ПреОбРазОвание строК')->upper(); ?></li>
<li><?php echo Str::lower('преоБразоВание СтроК'); ?> ИЛИ ТАК <?php echo Str::of('ПреОбРазОвание строК')->lower(); ?></li>
<li>Строка стала с прописной буквы: <?php echo 'все либерасты '.Str::ucfirst('ебаные мудаки. '); echo Str::of('либерасты -- пидерасты')->ucfirst(); ?></li>
<li>Заголовок все слова с большой буквы: <?php echo Str::title('цифровизация -- зло '); echo Str::of('нахуй цифровизаторов')->ucfirst(); ?></li>
<li>Вывод образанной строки по символам: <?php echo $init_str->limit(10); ?> или так <?php echo Str::limit('Весем евреям образают что?', 12, '...ХУЙ!!!'); ?></li>
<li>Вывод строки обрезанной по словам: <?php echo $init_str->words(4, '***'); ?> или так <?php echo Str::words('Идите на хуй пидорасы', 3, '!!!'); ?></li>
<li>Удалить начальные и конечные пробелы: ||<?php echo Str::of('    мууу   ')->trim(); ?>||</li>
<li>Удалить начальные пробелы: ||<?php echo Str::of(' мууу   ')->ltrim(); ?>||</li>
<li>Удалить конечные пробелы: ||<?php echo Str::of('    мууу   ')->rtrim(); ?>||</li>
<li>Без удаления пробелов: ||<?php printf('    мууу   '); ?>||</li>
<li>Вставка разделителя в строку и преобразование строки в англ транскрипцию: <?php echo Str::slug('хуй вам во все дыры', '-'); echo " ".Str::of('хуй вам во все дыры')->slug('&&&');  ?></li>
<li>Перевод строки в кодировку ascii:  <?php echo Str::of('Эта строка переведена в символы ascii!!!')->ascii(); echo " "; echo Str::ascii('И эта строка тоже!'); ?></li>
<li>Переписывает слова строки слитно с большой буквы: <?php echo Str::of('huj_nja')->studly(); ?> --работает только с англ буквами, а для русских просто сливает слова удаляя пробелы</li>
<li>Переписывает слова строки слитно с большой буквы: <?php echo Str::studly('huj_nja polnaja'); ?> --за разделитель принимает пробел или нижнее подчеркивание</li>
<li>Переводит строку в камелКейс:<?php echo Str::of('thsi_is camel ')->camel(); echo Str::camel(' с Русскими не_работает просто del probels'); ?></li>
<li>Делает из сторки люля-кебаб: <?php echo Str::of(' lula keBab')->kebab(); echo ' '.Str::kebab('И это шашлык realy testy!'); ?></li>
<li>Делает строку под стандарт названий php переменных: <?php echo Str::of('this is New-String')->snake(); echo ' '.Str::snake(' // и Это-такая Zmejka toje'); ?> -- для русских слов просто их соединяет и делает с маленькой буквы, для английских еще за разделитель принимает тире</li>
<li>Последнее существительное переводит во множественное число: <?php echo Str::of('How many chaild you have?')->plural(); echo ' '.Str::plural('stupid function child');  ?></li>
<li>Последнее слово преобразует в единичное число: <?php echo Str::of('You have rights!')->singular(); echo ' _'.Str::singular('this funktion is stupid to children'); ?></li>
<li> <?php echo '</br>'.Str::upper('извлечение фрагменТов СтРоК'); ?></li>
<li>Выдает подстроку, начинающуюся с символа с указанным номером и заданной длины: <?php echo $init_str->substr(2, 5); echo ' __'.Str::substr($initial_string, 5, 10); ?></li>
<li>Фрагмент строки ПЕРЕД первым вхождением подстроки: <?php echo Str::before($initial_string, 'rposes Of checking'); echo ' ______или так__'.$init_str->before('is'); ?></li>
<li>Фрагмент строки ПОСЛЕ первого вхождения подстроки: <?php echo Str::after($initial_string, 'rposes Of check'); echo ' _________или так__'.$init_str->after('is'); ?></li>
<li>Фрагмент строки ПОСЛЕ последнего вхождения подстроки: <?php echo Str::afterLast($initial_string, 'rposes Of check'); echo ' _________или так__'.$init_str->afterLast('is'); ?></li>
<li>Фрагмент между подстроками: <?php echo $init_str->between('ng_str', 'ion i'); echo '_____'.Str::between( $initial_string, 'is', 'ing'); ?> --если подстроки встречабтся несколько раз то берет так что фрагмент максимален(первое вхождение первой подстроки и последнее вхождение второй подстроки)</li>
<li>Разделяет строку по разделителю и возвращает коллекцию laravel: <?php var_dump($init_str->explode(' ')); ?></li>
<li>Проверка содержит ли подстроку: <?php if($init_str->contains('eck')) echo 'yes'; else echo 'no'; echo '____'; if(Str::contains($initial_string, ['RRR','is'])) echo('do'); else echo('dont'); ?></li>
<li>Проверка содержит ли подстроку: <?php if($init_str->containsAll(['eck', 'is'])) echo 'yes'; else echo 'no'; echo '____'; if(Str::containsAll($initial_string, ['RRR','is'])) echo('do'); else echo('dont'); ?></li>
<li>Проверка содержит ли подстроку: <?php if($init_str->startsWith(['eck', 'this is a'])) echo 'yes'; else echo 'no'; echo '____'; if(Str::startsWith($initial_string, ['RRR','this is a'])) echo('do'); else echo('dont'); ?></li>
<li>Проверка содержит ли подстроку: <?php if($init_str->endsWith(['ты хелперов', 'this is a'])) echo 'yes'; else echo 'no'; echo '____'; if(Str::endsWith($initial_string, ['RRR','this is a'])) echo('do'); else echo('dont'); ?></li>
<li>Соответствие регулярному выражению возвращает первый фрагмент соответствующий: <?php echo $init_str->match('/[a-z]+/'); ?></li>
<li>Соответствие регулярному выражению возвращает массив фрагментов соответствующий: <?php echo $init_str->matchAll('/[a-z]+/'); ?></li>
<li>Замена всех вхождений подстроки <?php echo $init_str->replace('is', 'RRRR'); ?></li>
<li>Замена первого подстроки <?php echo $init_str->replaceFirst('is', 'RRRR'); ?></li>
<li>Замена последнего подстроки <?php echo $init_str->replaceLast('is', 'RRRR'); ?></li>
<li>Замена очередного вхождения подстроки очередным элементом из массива <?php echo $init_str->replaceArray('t', ['RRRR', 'TTT']); ?> --если вхождений больше чем элементов массива остальные останутся неизменными</li>
<li>Замена совпадений регулярнрого выражения подстрокой или фрагментом-строкой из результата функции, задано кол-во замен 3 <?php echo $init_str->replaceMatches('/t+/', '*',3); ?></li>
<li>Замена совпадений регулярнрого выражения подстрокой или фрагментом-строкой из результата функции, задано кол-во замен 3 <?php echo $init_str->replaceMatches('/is+/', function($tmp){return Str::upper($tmp[0]);},3); ?></li>
<li> <?php echo '</br>'.Str::upper('обработка путей к файлам'); ?></li>
<li>Получить имя файла <?php echo Str::of('C:/domain/test/test.pdf')->basename(); ?> или без расширения <?php echo Str::of('C:/domain/test/test.pdf')->basename('.pdf'); ?></li>
<li> Получить директорию нужного уровня <?php echo Str::of('C:/domain/test/test.pdf')->dirname(2); ?> -- по умолчанию стоит 1 если не задать аргумент</li>
<li> <?php echo '</br>'.Str::of('ПрОчие инструменты обработки строк')->upper(); ?></li>
<li>Идентификатор uuid <?php echo Str::uuid().'.....'.Str::orderedUuid(); ?></li>
<li>Генерирует случайную строку <?php echo Str::random(15); ?></li>
<li>Если строка пуста вызывает анонимную функцию <?php echo Str::of('')->whenEmpty(function (){echo 'RRRRR';}); ?></li>
<li> <?php echo '</br>'.Str::of('обРАБотка массивов')->upper(); ?></li>
<li>Добавление элемента в конец массива если такого ключа нет или значение null: <?php $arr=['one'=>'pi', 'm'=>['m1'=>7,'m2'=>5]]; $arr=Arr::add($arr, 'one', 'huj'); $arr=Arr::add($arr, 'two', 'pizda'); var_dump($arr); ?></li>
<li>Добавить в начало элемент с значением (или если задан ключ, со значением и ключом): <?php $arr=['two'=>'hh', 'one'=>'pi']; $arr=Arr::prepend($arr, 'huj'); $arr=Arr::prepend($arr, 'bladj'); var_dump($arr); ?>
 -- в книге ошибка, сначала Значение затем Ключ т.к. ключ не обязательный. 
Если ключ не задать то добавит элемент с ключом-номером минимального элемента элементы с числовыми ключами сдвинет</li>
<li>Установить значение для элемента с заданным ключом: <?php $arr=['t'=>3, 'ttt'=>'7t', 'tt'=>['r'=>'r6', 'rrr'=>'r2']]; Arr::set($arr, 'tt.0', 'HHH'); var_dump($arr);  ?> -- если такого ключа нет то присоеденит новый элемент в конец массива</li>
<li>Удалить элемент\элементы с ключом\ключами (ничего НЕ ВОЗВРАЩАЕТ): <?php $arr=['t'=>'t3', 'tt'=>'t2', 'y'=>['y5'=>4, 'y8'=>9], '3'=>'gg']; Arr::forget($arr,['y.y5','tt', '0']); var_dump($arr);  ?> -- если попробовать удалить ключ которого нет то ничего не делает с этим ключом, е те что есть удаляет</li>
<li>Удалить элемент\элементы с ключом\ключами (ничего ВОЗВРАЩАЕТ полученный массив): <?php $arr=['t'=>'t3', 'tt'=>'t2', 'y'=>['y5'=>4, 'y8'=>9], '3'=>'gg']; $arr=Arr::except($arr,['y.y5','tt', '0']); var_dump($arr);  ?> -- если попробовать удалить ключ которого нет то ничего не делает с этим ключом, е те что есть удаляет</li>
<li>Получить элемент по ключу: <?php $arr=['t'=>'t3', 'tt'=>'t2', 'y'=>['y5'=>4, 'y8'=>9], '3'=>'gg']; echo Arr::get($arr, 'y.y8'); echo ' '.Arr::get($arr,'rrr','netu nihuja!') ?></li>
<li>Забрать элемент по ключу и удалить из массива <?php $arr=['t'=>'t3', 'tt'=>'t2', 'y'=>['y90'=>'tertgr','y5'=>4, 'y8'=>9], '3'=>'gg']; echo ' '.Arr::pull($arr, 'y.y5'); var_dump($arr); ?> --если ключа нет ничего не делает возврат null</li>
<li>Выборка из массива элементов по условию (выберет те элементы для которых функциЯ вернет true): <?php $result=Arr::where([1,2,3,'t'=>4,5,6,7,8], function($element){return $element%2 == 0;}); var_dump($result); ?></li>
<li>Получить ЗНАЧЕНИЕ первого элемента для которого функция вернет true: <?php echo Arr::first(['port'=>'4t', 'sort'=>345, 'r'=>'sort'],function($value, $index){return $index == 0;}, 'no here'); ?> --в качестве индекса подходит ключ или числовой индекс</li>
<li>Получить ЗНАЧЕНИЕ последнего элемента для которого функция вернет true: <?php echo Arr::last(['port'=>'4t', 'sort'=>345, 'r'=>9, 'yt'=>8],function($value, $index){return $value > 7;}, 'no here'); ?> --в качестве индекса подходит ключ или числовой индекс</li>
<li>Выбрать из массива элементы, чьи ключи содержатся в массиве-запросе: <?php $mass=['i'=>6, '5'=>null, 'tt'=>'456ert']; $request=['5', 'i', 'rrr']; $arr=Arr::only($mass,$request); var_dump($arr); ?>-- если в запросе ключи которых нет в массиве вернет только те которые нашел в массиве</li>
<li>Составить из элементов массива с заданным ключом массив: <?php $arr=['round'=>['yy'=>['round'=>88]], 'type'=>['round'=>3, 'square'=>5],'color'=>['round'=>'green', 'triangle'=>'red'], 'mm'=>['88', 'round'=>'EEE', '99', '87']]; 
										$res=Arr::pluck($arr, 'round'); var_dump($res); ?> --не видит элементы в уровнях 1 и больше 2, видит только на 2 уровне вложения, + находит лишний нулевой элемент--хрен поймешь алгоритм</li>
<li> <?php echo '</br>'.Str::of('ПрОверка суЩестВоВания эЛеменТов массивов')->upper(); ?></li>
<li>Проверить есть ли элемент с таким ключом: <?php $arr=['t'=>456, 'tt'=>null, 3=>234]; if(Arr::exists($arr, 'tt')) echo 'yes'; ?></li>
<li>Проверить есть ли в массиве ВСЕ элементы с заданными ключами: <?php $arr=['t'=>456, 'tt'=>['i'=>5, 'ii'=>'j'], 3=>234]; if(Arr::has($arr, ['t', 'tt.ii'])) echo 'yes'; else echo 'no';  ?>--вместо массива ключей можно использовать один ключ</li>
<li>Проверить есть ли в массиве ХОТЯ-БЫ ОДИН из перечисленных ключей <?php  $arr=['t'=>456, 'tt'=>['i'=>5, 'ii'=>'j'], 3=>234]; if(Arr::hasAny($arr, ['t345', 'tt.ii', 'NONONONO'])) echo 'yes'; else echo 'no';   ?></li>
<li> <?php echo '</br>'.Str::of('Получение сведений о массиве')->upper();  ?></li>
<li>Проверить является массивом или коллекцией Ларвел <?php Arr::accessible(7)?printf('DA'):printf('NET'); ?></li>
<li>Является ли массив ассоциативным: <?php Arr::isAssoc([1,5,'7rt'=>'swersdf',9])?printf('DA'):printf('NET'); ?></li>
<li> <?php echo '</br>'.Str::of('сортировка эЛеменТов массивов')->upper();  ?></li>
<li>Сортировка по возрастанию ЗНАЧЕНИЙ: <?php $arr=Arr::sort([2=>['name'=>'uu', 'id'=>7], 5=>['name'=>'rr', 'id'=>7], 'wer6'=>['name'=>'tt', 'id'=>5]],function($el){return $el['id'];}); var_dump($arr); ?>--для многомерного массива указать функцию выбирающую ЗНАЧЕНИЕ какого ключа во вложенном массиве выбрано как параметр для сортировки</li>
<li>Рекурсивная сортировка массива и вложенных массивов (ПО ЗНАЧЕНИЯМ!!!): <?php $arr=Arr::sortRecursive([2=>['name'=>'uu', 'id'=>1], 5=>['name'=>'rr', 'id'=>7], 'wer6'=>['name'=>'tt', 'id'=>5]]); var_dump($arr); ?></li>
<li>Переусовка массива вразнобой с переназначением значений элементов массива(если указанно): <?php $arr=[1,2,3,4,5,6]; $res=Arr::shuffle($arr); var_dump($res); ?> -- исходный массив остается нетронутым</li>
<li> <?php echo '</br>'.Str::of('прочие инструменты обработка массивов')->upper(); ?></li>
<li>Разделить массив на 2 массива один из ключей один из значений: <?php var_dump(Arr::divide(['t'=>3,'u'=>87,'pp'=>'ty'])); ?></li>
<li>Уменьшить размерность массива на 1: <?php var_dump(Arr::collapse(['t'=>['t6'=>6, 't7'=>7], 'u'=>['yy'=>2, 't6'=>'7']])); ?> --если при коллапсе в массивах подуровня есть елементы с одинаковыми ключами он их перезапишет последним значением</li>
<li>Превратить многомерный в одномерный: <?php var_dump(Arr::flatten(['t'=>['tt'=>8, 'u8'=>[1,2,3]], 'u'=>['rt'=>'r', 'vb'=>'dfdsf', 'jk'=>3]])); ?>--если массив был ассоциативный станет индексный</li>
<li>Сделать одномерным ассоциативным: <?php var_dump(Arr::dot(['t'=>['tt'=>8, 'u8'=>[1,2,3]], 'u'=>['rt'=>'r', 'vb'=>'dfdsf', 'jk'=>3]])); ?></li>
<li>Получить декартово произведение нескольких массивов: <?php var_dump(Arr::crossJoin(['a','b'],[1,2])); ?></li>
<li>Составить из элементов масссива GET параметры: <?php echo Arr::query(['id'=>6, 'name'=>'roma']); ?></li>
<li>Выбрать из массива несколько случайных элементов: <?php var_dump(Arr::random([1,2,3,4,5], 2)); var_dump(Arr::random([1,'t'=>2,3,'y'=>4,5]));  ?> </li>
<li>Сделать из элемента массив: <?php var_dump(Arr::wrap(234));  ?> --если это уже массив то ничего не делает, если null вернет пустой массив</li>
<li> <?php echo '</br>'.Str::of('функЦИИ ХЕЛПеры')->upper();  ?> </li>
<li>Путь к папке проекта: <?php echo base_path(); echo ' .+название файла ..'.base_path('../../../login.blade.php');  ?> --не пишет реальный путь к файлу а просто имя файла(или написанный путь как есть) добавляет к папке проекта</li>
<li>Путь к папке app / resources / storage: <?php echo app_path().'....'.resource_path().'....'.storage_path().'...'.public_path();  ?> </li>
<li>Объект Carbon с текущей временной отметокой: <?php var_dump(now());  ?> </li>
<li>Объект Carbon с текущей датой: <?php var_dump(today());  ?> </li>
<li>Проверяет пустое ли значение или объект(ноль не пустое число, строка из пробелов пуста): <?php blank('   ')?printf('blank'):printf('no'); ?> </li>
<li>Проверяет НЕ пустое ли значение или объект(ноль не пустое число, строка из пробелов пуста): <?php filled('   ')?printf('blank'):printf('no'); ?> </li>
<li>Для не пустых значений возвращает результат анонимной функции а для пустых значение по умолчанию: <?php printf( transform('   ', function(){return 'GO';}, 'NO content'));  ?> </li>
<li>Вызвать метод у любого объекта и вернуть как результат заданный объект: <?php use App\Http\Controllers\cityMenuController; $t=new cityMenuController(); var_dump(tap($t));  ?> </li>
<li>Обратиться к любому свойству объекта даже нулевому без вызова исключения: <?php use App\City; $c=new City(); echo optional($c)->state_capital;  ?> </li>
<li>ВАЖНО!!!! Показать перечень трейтов использованных классом: <?php var_dump(class_uses_recursive($c));  ?> </li>
<li>ВАЖНО!!!! Показать перечень трейтов использованных ТРЕЙТОМм: <?php var_dump(trait_uses_recursive('\Illuminate\Support\Str'));  ?> </li>
<li> <?php  ?> </li>
<li> <?php  ?> </li>
<li> <?php  ?> </li>
<li></li>









</ol>

</br></br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/adminPanel.blade.php ENDPATH**/ ?>