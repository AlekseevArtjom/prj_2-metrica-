


<?php $__env->startPush('stylesheets_for_metrica'); ?>
	<link type="text/css" rel="stylesheet" href="styles/metricaMainStyle.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('stylesheets_for_metrica'); ?>
	<link type="text/css" rel="stylesheet" href="styles/metricaMainPageStyle.css"/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title'); ?>
	MetricaPage::addSite
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main'); ?>

<h1>Добавление нового сайта</h1>

<form method="POST" action="<?php echo e(route('doAdSite')); ?>">
	<?php echo csrf_field(); ?>
	<input type="text" name="siteDomainURL" placeholder="Введите полный url адрес сайта" value="<?php echo e(old('siteDomainURL')); ?>" />
	<input type="submit" value="Добавить" />
	<input type="button" value="Отмена" onclick="(function(){window.location.href='<?php echo e(route('showMetricaPage')); ?>';})();" />
</form>
<?php $__errorArgs = ['siteDomainURL'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\OpenServerBasic\OSPanel\domains\localhost\resources\views/addSiteForm.blade.php ENDPATH**/ ?>