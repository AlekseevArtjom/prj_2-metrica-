
<?php $__env->startSection('title', 'Проба валидации'); ?>

<?php
	$requestNewUser='on'; /* для того чтобы на этой стр из шаблона выводился пункт меню "Регать польз-я" */
?>
<?php $__env->startSection('main'); ?>

<form method="POST" action="<?php echo e(route('testValidationAction')); ?>">
	<?php echo csrf_field(); ?>
	<input type="text" placeholder="Enter name" name="his_name" value="<?php echo e(old('his_name')); ?>" /> <?php $__errorArgs = ['his_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	<input type="text" placeholder="Enter last name" name="his_last_name" value="<?php echo e(old('his_last_name')); ?>" /> <?php $__errorArgs = ['his_last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
	<input type="submit" value="Валидация!" />
</form>

<input type="button" value="Validate it now!_no work" name="validator_go" onclick="(function(){ window.location.href=''; })();" />
</br>		
	
</br>
<form id="long" method="POST" action="<?php echo e(route('testMyRequest')); ?>" style="border: solid grey 1px;">
	<?php echo csrf_field(); ?>
	<?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    <input type="text" name="age" value="<?php echo e(old('age')); ?>"  placeholder="Напиши возраст" /></br>
	<?php $__errorArgs = ['manName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="manName" value="<?php echo e(old('manName')); ?>"  placeholder="Напиши имя" /></br>
	<?php $__errorArgs = ['hobby'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="hobby" value="<?php echo e(old('hobby')); ?>"  placeholder="Напиши хобби" /></br>
	<?php $__errorArgs = ['myurl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  <input type="text" name="myurl" value="<?php echo e(old('myurl')); ?>"  placeholder="Запиши адрес сайта" /></br>
	<?php $__errorArgs = ['myMail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   <input type="text" name="myMail" value="<?php echo e(old('myMail')); ?>"  placeholder="Напиши свою почту" /></br>
	<?php $__errorArgs = ['password9'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="password9" value="<?php echo e(old('password9')); ?>"  placeholder="Введи пробный пароль" /></br>
	<?php $__errorArgs = ['password9_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="password9_confirmation" value="<?php echo e(old('password9_confirmation')); ?>"  placeholder="Повтори пробный пароль" /></br>
	<?php $__errorArgs = ['birthDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="birthDate" value="<?php echo e(old('birthDate')); ?>"  placeholder="Впиши дату рождения в виде дд.мм.гг" /></br>
	<?php $__errorArgs = ['fieldValidByFunction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="fieldValidByFunction" value="<?php echo e(old('fieldValidByFunction')); ?>"  placeholder="Угадай число!" /></br>
	<?php $__errorArgs = ['NumberMore2Class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <input type="text" name="NumberMore2Class" value="<?php echo e(old('NumberMore2Class')); ?>"  placeholder="Введи число больше 2" /></br>
	<!-- <input type="text" name="" value=""  placeholder="" /></br> -->

		<input type="submit" name="go2" value="Go request"  />
</br></br>$errors=<?php echo e($errors); ?>

</form>


<style> #long input {width: 20%;} </style>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/validateViewTest.blade.php ENDPATH**/ ?>