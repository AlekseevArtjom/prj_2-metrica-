<div style="border: solid 3px green;">
	Every country has <?php echo e($countryStatus); ?>!!!
</div><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/shared/listOfCountryes.blade.php ENDPATH**/ ?>