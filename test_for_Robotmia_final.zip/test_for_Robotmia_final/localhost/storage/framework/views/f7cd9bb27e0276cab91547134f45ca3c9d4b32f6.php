


<?php $__env->startSection('title', 'Main page'); ?>
<?php $__env->startSection('menu', '_____here will be menu_____'); ?>
<?php $__env->startSection('main'); ?>

	<h2>Start page</h2>
	<p>start cite with showing <strong>this</strong> page</p>
	<?php if(auth()->guard()->check()): ?><h2>Добро пожаловать <?php echo e(Auth::user()->name); ?></h2> <?php endif; ?>
	
	<a href="<?php echo e(route('cityList')); ?>">К списку городов</a></br>
	<a href="<?php echo e(route('CitySiteRes.index')); ?>">К списку достопримечательностей</a></br>
	</br></br><a href="<?php echo e(route('redirectNaHuj')); ?>">На хуй туда</a></br>
	<a href="<?php echo e(route('citeCreator')); ?>">Разработчик сайта</a></br>

</br></br><a href="<?php echo e(route('showFile', ['filename'=>'KluchMatjash10.pdf'])); ?>">Показать файл</a>

</br></br><form method="POST" enctype="multipart/form-data"  action="<?php echo e(route('sendFileToServer')); ?>" >
	<?php echo csrf_field(); ?>
	<?php $__errorArgs = ['sendFile2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?>  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  
	<input style="border: solid green 1px;" type="file" name="sendFile2" />
	<input style="border: solid green 1px;" type="file" name="sendFile3" />
	<input type="submit" value="отправить файл" />
</form>

</br></br> <form method="GET" action="<?php echo e(route('takeFile5')); ?>"> <input style="width: 30vw" type="text" placeholder="Для получения файла введите его название!" /> <input type="submit" value="Получить файл" /> </form>
<img alt="Image not found" src="<?php echo e(asset('storage/app/public/tmp_my1/new_my_file1.png')); ?>" /> <!-- ВАЖНО эта функция фасада задает путь от корня каталога сайта, 
											а сохранение в storage задает(и возвращает) пути от storage/app 
										   ВАЖНО а для отображения картинки путь ДОЛЖЕН БЫТЬ ЗАДАН ОТНОСИТЕЛЬНО localhost/public
											поэтому для отображения из хранилища требуется перед этим создать символическую ссылку на папку хранилища
												storage/app/public (php artisan storage:link .....) и внее размещать все что хотим отобразить -->


</br></br><a href="<?php echo e(route('showFile', ['filename'=>'KluchMatjash20.pdf'])); ?>">Показать файл</a>
</br></br><a href="<?php echo e(route('showFile', ['filename'=>'no'])); ?>">Показать файл работа noContent</a>
</br></br><a href="<?php echo e(route('showFile', ['filename'=>'nono'])); ?>">Показать файл работа abort</a>
 </br></br><a href="">Сохранить файл на диск файл</a> </br></br>

</br></br><a href="<?php echo e(route('testValidationPage')); ?>">Проверить валидатор</a></br></br>
<a href="<?php echo e(route('collections')); ?>">Колллекции<a/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.initial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/StartPage.blade.php ENDPATH**/ ?>