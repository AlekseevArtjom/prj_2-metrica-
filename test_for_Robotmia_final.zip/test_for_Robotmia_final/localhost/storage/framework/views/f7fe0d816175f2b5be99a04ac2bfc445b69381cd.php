<div id="menu">
	<div class="menu_item"><a href="<?php echo e(route('startPage')); ?>">На главную страницу</a></div>
	<?php if(!isset($admin)): ?>
	<div class="menu_item">
		<a href="<?php echo e(route('showAdminPanel')); ?>">Панель администратора</a>
	</div>
	<?php endif; ?>
	<div class="menu_item">
		<?php if(auth()->guard()->guest()): ?>
			<a href="<?php echo e(route('login')); ?>">Вход</a>
		<?php endif; ?>
		<?php if(auth()->guard()->check()): ?>
		<?php if(!isset($admin)): ?>
				<form style="display: inline-block;" method="POST" action="<?php echo e(route('logout')); ?>">
				<?php echo csrf_field(); ?>
				<input type="submit" value="Выход" /></form>
			<?php else: ?> 	<form style="display: inline-block;" method="POST" action="<?php echo e(route('logout')); ?>">
				<?php echo csrf_field(); ?>
				<input type="submit" value="Выход из админки" /></form>
		<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php if($requestNewUser=='on'): ?> 
	<div class="menu_item">
			<?php if(auth()->guard()->check()): ?>
				<a href="#" >Зарегистрировать пользователя</a>
			<?php else: ?> 	<a href="<?php echo e(route('register')); ?>">Зарегистрировать пользователя</a>
			<?php endif; ?>
	</div>
	<?php endif; ?>
</div>


<style>
#menu 
{
	bacckrgound-color: rgeen;
	font-weight: bold;
	color: red;
}

.menu_item
{	
	display:inline-block;
	border: solid red 2px;
}
.menu_item:hover { font-style: italic; }
</style><?php /**PATH E:\OpenServerBasic\OSPanel\domains\localhost\resources\views/shared/menuMyBlade.blade.php ENDPATH**/ ?>