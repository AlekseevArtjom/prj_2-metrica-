<div>
    your try to bye the detail: {{$detailName}}
</div>